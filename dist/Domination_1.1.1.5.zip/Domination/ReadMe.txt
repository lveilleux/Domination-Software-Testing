Domination - Yura Mamyrin (yura@yura.net)

SUN Java 1.4 or higher must be installed to run Domination

Miniumum Resolulation is 1024x768

For information look in the manual or visit http://domination.sf.net/

ChangeLog.txt - A history of changes in this and earlier Domination version
BugTrack.txt  - A list of known bugs and sugestions people have made

The full source to Risk is included in src.zip

Domination is under the GNU General Public License, see gpl.txt for more details.

send questions and comments to: yura@yura.net

Copyright (c) 2003-2012 yura.net
